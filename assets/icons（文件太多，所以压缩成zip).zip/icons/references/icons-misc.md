# 其他 Misc

共 11 个图标

## zap

**关键词**: 闪电,能量,zap,lightning,bolt,energy,power,electric,fast,charge

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
```

## crown

**关键词**: 皇冠,crown,royal,king,queen,winner,best,premium,top

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"/><path d="M5 21h14"/></svg>
```

## sword

**关键词**: 剑,武器,sword,blade,weapon,fight,combat,game,knight

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="14.5 17.5 3 6 3 3 6 3 17.5 14.5"/><line x1="13" y1="19" x2="19" y2="13"/><line x1="16" y1="16" x2="20" y2="20"/><line x1="19" y1="21" x2="21" y2="19"/></svg>
```

## skull

**关键词**: 骷髅,skull,death,dead,halloween,danger,poison,pirate

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="12" r="1"/><circle cx="15" cy="12" r="1"/><path d="M8 20v2h8v-2"/><path d="m12.5 17-.5-1-.5 1h1z"/><path d="M16 20a2 2 0 0 0 1.56-3.25 8 8 0 1 0-11.12 0A2 2 0 0 0 8 20"/></svg>
```

## alien

**关键词**: 外星人,alien,extraterrestrial,ufo,space,creature,monster,scifi

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a7 7 0 0 0-7 7c0 2.5 1.5 5 3 6.5V17a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2v-1.5c1.5-1.5 3-4 3-6.5a7 7 0 0 0-7-7Z"/><path d="M9 12h.01"/><path d="M15 12h.01"/><path d="M10 16c.5.5 1 .5 2 .5s1.5 0 2-.5"/></svg>
```

## butterfly

**关键词**: 蝴蝶,butterfly,insect,nature,wings,spring,colorful,transform

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 12.5c0-2.5 2-4 4-4 1.5 0 3 .5 3 2.5 0 2-2 3-4 3-.5 0-1-.5-1-1.5Z"/><path d="M12 12.5c0-2.5-2-4-4-4-1.5 0-3 .5-3 2.5 0 2 2 3 4 3 .5 0 1-.5 1-1.5Z"/><path d="M12 12.5c0 2.5-2 4.5-4 4.5-1.5 0-3-.5-3-2.5 0-2 2-3 4-3 .5 0 1 .5 1 1Z"/><path d="M12 12.5c0 2.5 2 4.5 4 4.5 1.5 0 3-.5 3-2.5 0-2-2-3-4-3-.5 0-1 .5-1 1Z"/><path d="M12 12.5V22"/><path d="M12 9V4"/><path d="M12 4c-1-1-1-2 0-3 1 1 1 2 0 3Z"/></svg>
```

## fish

**关键词**: 鱼,fish,animal,water,sea,ocean,swim,aquarium,food

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6.5 12c.94-3.46 4.94-6 8.5-6 3.56 0 6.06 2.54 7 6-.94 3.47-3.44 6-7 6s-7.56-2.53-8.5-6Z"/><path d="M18 12v.5"/><path d="M16 17.93a9.77 9.77 0 0 1 0-11.86"/><path d="M7 10.67C7 8 5.58 5.97 2.73 5.5c-1 1.5-1 5 .23 6.5-1.24 1.5-1.24 5-.23 6.5C5.58 18.03 7 16 7 13.33"/></svg>
```

## mushroom

**关键词**: 蘑菇,mushroom,fungus,toadstool,food,forest,nature,magic

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21a9 9 0 0 1-9-9c0-4.97 4.03-9 9-9s9 4.03 9 9a9 9 0 0 1-9 9Z"/><path d="M12 12v9"/><path d="M3 12h18"/></svg>
```

## flame-kindling

**关键词**: 篝火,营火,bonfire,campfire,fire,warm,camping,heat

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 2 1.5 3H18l-2.5 2L17 10l-5-2-5 2 1.5-3L6 5h4.5z"/><path d="M5 22h14"/><path d="M7 18c0-2 2-3 5-3s5 1 5 3"/></svg>
```

## meteor

**关键词**: 流星,meteor,shooting-star,space,comet,fall,fast,sky

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9.5 5.5 11 7l-1.5 1.5L8 7z"/><path d="M14.5 10.5 16 12l-1.5 1.5L13 12z"/><path d="M3 21 21 3"/><path d="M21 3v6"/><path d="M21 3h-6"/></svg>
```

## bike-2

**关键词**: 自行车,bike,bicycle,cycle,ride,sport,transport,pedal

**SVG代码**:

```svg
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="6" cy="17" r="3"/><circle cx="18" cy="17" r="3"/><path d="M6 17V7l4 4h4l4-4v10"/><path d="M10 11V7h4"/></svg>
```
