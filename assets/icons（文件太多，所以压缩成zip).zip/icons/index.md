# icons —— 图标库

S-IDE 和 S++ 应用共用这一套线性图标。177 个，19 个分类。

## 来源与许可

**这套图标来自 Morphicons**（2026-09-26 由项目所有者确认）。

⚠️ 上面那句「S-IDE 和 S++ 应用共用」说的是**谁在用**，不是谁画的 ——
曾经据此误判成「本项目自带」，在「关于」页的开源组件表里标成了「本项目 / 本项目」，
现已订正为「Morphicons」。

**许可：待确认。** 公开检索到的 "Morphicons" 只有 2026 年那个图标**变形动画库**
（MIT，作者 Guillermo López González，github.com/guillermolg00/morphicons），
不是图标集，两者的许可不能互相套用。「关于」页的许可列目前写的是「见官方授权」，
**不许随手填成 MIT**。确认后改两处：`ui/Lang.cs` 的 `about.license.unknown`
（中英各一条），以及本节这段说明。

```
assets/icons/
├── *.svg              177 个图标源文件
├── icons.json         索引：每个图标的 keywords / category / svg 源码
├── index.md           本文件
└── references/        19 个分类清单（icons-basic.md 等）
```

## 规格

| 项 | 值 |
|---|---|
| 设计尺寸 | 24 × 24 |
| 风格 | 线性描边，不填充 |
| 线宽 | 2（缩放时按比例，最小 1px） |
| 颜色 | 单一色，绘制时指定 |
| 格式 | SVG，`stroke="currentColor"` 语义 |

因为是单色描边，任意尺寸、任意颜色都能重画，不需要为每个颜色准备一套图。
图标本身不含任何硬编码颜色，颜色全部来自 `ui/theme.cpp`。

## 用法

```cpp
#include "icons/iconlib.h"

icons::Library lib("assets/icons");
lib.load();                    // 读 icons.json
lib.warmAll();                 // 预解析全部（启动时一次）

// 画一个图标
const auto& sh = lib.shapes("folder-open");
icons::draw(canvas, sh, x, y, 16, theme.fgPrimary);
```

搜索（支持中文关键词）：

```cpp
auto hits = lib.search("文件", 8);   // → file, folder, folder-open
auto hits2 = lib.search("play", 8);
```

## S-IDE 界面用到的图标

| 位置 | 图标 | 说明 |
|---|---|---|
| 工具栏-新建 | `plus` | |
| 工具栏-打开 | `folder-open` | |
| 工具栏-保存 | `save` | |
| 工具栏-运行 | `play` | |
| 工具栏-构建 | `package` | |
| 工具栏-部署到安卓 | `smartphone` | |
| 工具栏-检查 | `check-circle` | |
| 工具栏-格式化 | `wand-2` | |
| 工具栏-设置 | `settings` | |
| 工具栏-主题 | `sun` / `moon` | 浅色 / 深色 |
| 侧栏-项目 | `folder` | |
| 侧栏-搜索 | `search` | |
| 侧栏-日志 | `file-text` | |
| 欢迎页-新建项目 | `plus-circle` | |
| 欢迎页-打开项目 | `folder-open` | |
| 欢迎页-最近 | `clock` | |

## 文件树按类型映射

| 文件 | 图标 |
|---|---|
| `.spros` | `code` |
| `.sxml` | `layers` |
| `.cxml` | `palette` |
| `.ixml` | `pen-tool` |
| `build.sbuild` | `wrench` |
| `app.Manifest` | `file-text` |
| `android.Manifest` | `smartphone` |
| `.png` `.jpg` `.svg` | `image` |
| `.md` | `book` |
| 未知 | `file` |

## 诊断级别

| 级别 | 颜色 | 图标 |
|---|---|---|
| 错误 | 红 `#E54C4C` | `x-circle` |
| 警告 | 灰白 `#D8D8DC` | `alert-triangle` |
| 提示 | 灰 `#9A9AA0` | `info` |
| 通过 | 绿 `#4CC06A` | `check-circle` |

配色只用黑、灰、白、红、绿。详见 `src/ui/theme.cpp`。

## 分类分布

| 分类 | 数量 | 分类 | 数量 |
|---|---|---|---|
| basic | 19 | navigation | 16 |
| dev | 15 | media | 14 |
| system | 14 | files | 12 |
| misc | 11 | business | 10 |
| weather | 10 | creative | 7 |
| games | 7 | security | 7 |
| communication | 6 | science | 6 |
| user | 6 | education | 5 |
| food | 5 | travel | 4 |
| time | 3 | | |

## 解析支持的 SVG 图元

`<path>` `<polyline>` `<polygon>` `<line>` `<circle>` `<rect>` `<ellipse>`

`<path>` 的 `d` 属性支持 `M L H V C S Q T A Z`，大小写（绝对/相对坐标）都可。
曲线按 12 段折线离散化，圆弧按 SVG 规范做中心参数化。

### 数字分词的坑

SVG 的 path data 会把数字挤在一起写：

```
1.35.09     表示 1.35 和 0.09 两个数
-1.25.5     表示 -1.25 和 0.5
```

**第二个小数点是数字分隔符，不是小数点。** 用 `strtod` 一个个读会在
`-1.25.5` 这类数据上连符号一起读错，导致含圆弧的图标（`cat`、`puzzle`）
整体解析失败、画出来是空白。

`src/icons/svg.cpp` 里的 `NumScanner` 用状态机处理：遇到第二个 `.`、
或遇到非首位且非指数位的 `+`/`-`，就结束当前数字。

已验证：**177/177 解析成功，共 565 个图形。**

## 全部图标名

```
activity          alarm-clock       alert-circle      alert-triangle
alien             anchor            aperture          apple
arrow-down        arrow-left        arrow-right       arrow-up
arrow-up-right    at-sign           atom              award
balloon           bar-chart-2       battery           bell
bike              bike-2            bluetooth         book
bookmark          box               briefcase         brush
bug               building          cake              calculator
calendar          camera            car               cat
check             check-circle      chevron-down      chevron-left
chevron-right     chevron-up        clock             cloud
cloud-rain        code              coffee            coin
command           compass           copy              cpu
credit-card       crop              crosshair         crown
database          dice              download          droplet
edit              emoji             eye               eye-off
facebook          feather           file              file-text
film              filter            fingerprint       flag
flame             folder            folder-open       gamepad
gift              git-branch        git-commit        git-merge
git-pull-request  globe             grid              hard-drive
hash              headphones        heart             help-circle
home              hourglass         image             inbox
info              instagram         key               layers
layout            leaf              library           lightbulb
link              linkedin          list              loader
lock              lock-open         log-in            log-out
mail              map               map-pin           maximize
megaphone         menu              message-circle    message-square
mic               mic-off           minimize          minus
moon              more-horizontal   more-vertical     mouse-pointer
move              music             navigation        octagon
package           palette           paperclip         pause
pen-tool          percent           phone             pie-chart
pin               pizza             play              plus
plus-circle       pocket            power             printer
puzzle            radio             refresh           repeat
rewind            rocket            rotate            ruler
save              scissors          search            send
server            settings          share             shield
shopping-bag      shopping-cart     shuffle           sidebar
skip-back         skip-forward      sliders           smartphone
smile             speaker           square            star
stop              stop-circle       sun               sunrise
sunset            table             tablet            tag
target            terminal          thermometer       thumbs-down
thumbs-up         toggle-left       toggle-right      tools
trash             trash-2           trending-down     trending-up
triangle          trophy            truck             tv
twitch            twitter           umbrella          underline
unlock            upload            user              user-check
user-minus        user-plus         users             video
video-off         volume            volume-1          volume-2
volume-x          wallet            watch             wifi
wifi-off          wind              wrench            x
x-circle          x-octagon         youtube           zap
zoom-in           zoom-out
```
